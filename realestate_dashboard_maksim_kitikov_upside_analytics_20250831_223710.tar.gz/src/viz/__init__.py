# Visualization Module
# Handles charts, maps, and interactive visualizations
